import os, json
from datetime import datetime, timedelta, timezone
from langchain_core.prompts import PromptTemplate
from langchain_classic.schema import HumanMessage
from langchain_groq import ChatGroq

class AIDetector:
    def __init__(self, model_name="meta-llama/llama-4-scout-17b-16e-instruct",
                 api_key=None, temperature=0.0, local_small_amount_threshold=5.0,
                 local_small_count_threshold=8, local_window_minutes=60):
        self.model_name = model_name
        self.api_key = api_key or os.environ.get("API_KEY")
        self.temperature = temperature
        self.local_small_amount_threshold = local_small_amount_threshold
        self.local_small_count_threshold = local_small_count_threshold
        self.local_window_minutes = local_window_minutes

        # so the UI can run without a key
        if self.api_key:
            self.llm = ChatGroq(model_name=self.model_name, temperature=self.temperature, api_key=self.api_key)
        else:
            self.llm = None

        self.prompt_template = PromptTemplate(
            input_variables=["transactions", "now_iso"],
            template=(
                "You are a senior financial crimes analyst. You are given a JSON array of recent transactions "
                "across many accounts. Each transaction contains id, type (deposit/withdraw/transfer_in/transfer_out), "
                "amount, timestamp (ISO UTC), account, and optional from/to. \n\n"
                "Analyze the transactions for patterns consistent with money laundering, structuring (smurfing), "
                "layering, rapid consolidation, or other suspicious activity. Produce a JSON object with a single key "
                "'alerts' mapping to a list of alerts. Each alert must contain: "
                "{ 'account_id', 'severity' ('low'|'medium'|'high'), 'reason', 'example_transactions' }.\n\n"
                "Only return valid JSON. Use at most 3000 tokens. Now: transactions = {transactions}\n"
                "Current time: {now_iso}\n\n"
                "Be concise; return pure JSON."
            )
        )

    def local_heuristic(self, transactions):
        """detect small transfers into a single account within a short window"""
        from collections import defaultdict
        suspicious = []
        now = datetime.now(tz=timezone.utc)
        window_start = now - timedelta(minutes=self.local_window_minutes)
        counts = defaultdict(list)
        for t in transactions:
            tts = t.get("timestamp")
            try:
                ttime = datetime.fromisoformat(tts.replace("Z", "+00:00"))
            except Exception:
                continue
            if ttime < window_start:
                continue
            if t.get("type") in ("transfer_in", "deposit"):
                amt = float(t.get("amount", 0))
                if amt <= self.local_small_amount_threshold:
                    counts[t.get("account")].append(t)
        for acct, txs in counts.items():
            if len(txs) >= self.local_small_count_threshold:
                suspicious.append({
                    "account_id": acct,
                    "severity": "high" if len(txs) >= self.local_small_count_threshold * 2 else "medium",
                    "reason": f"{len(txs)} small deposits/transfers (<= {self.local_small_amount_threshold}) into account within last {self.local_window_minutes} minutes.",
                    "example_transactions": txs[:5]
                })
        return suspicious

    def llm_analyze(self, transactions):
        if not self.llm:
            return {"alerts": [], "note": "No API key configured; LLM analysis skipped."}
        txs_small = transactions[:300]
        prompt = self.prompt_template.format_prompt(transactions=json.dumps(txs_small), now_iso=datetime.utcnow().isoformat() + "Z").to_string()
        # call model
        try:
            res = self.llm([HumanMessage(content=prompt)])
            content = ""
            if isinstance(res, list):
                first = res[0]
                content = getattr(first, "content", None) or first.get("content", "") if isinstance(first, dict) else str(first)
            else:
                content = getattr(res, "content", str(res))
            parsed = json.loads(content)
            return parsed
        except Exception as e:
            return {"alerts": [], "error": f"LLM call failed: {str(e)}"}

    def analyze(self, transactions):
        """Run both local heuristic + LLM, return combined alerts and explanation."""
        local = self.local_heuristic(transactions)
        llm_result = self.llm_analyze(transactions)
        alerts = []
        if isinstance(llm_result, dict):
            alerts.extend(llm_result.get("alerts", []))
        elif isinstance(llm_result, list):
            alerts.extend(llm_result)
        existing_accts = {a["account_id"] for a in alerts if "account_id" in a}
        for a in local:
            if a["account_id"] not in existing_accts:
                alerts.append(a)
        return {"alerts": alerts, "local_count": len(local), "llm_note": llm_result.get("note") if isinstance(llm_result, dict) else None}
