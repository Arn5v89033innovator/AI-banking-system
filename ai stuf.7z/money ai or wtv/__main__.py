import customtkinter as ctk
import threading
import time
from data_manager import *
from ai_detector import AIDetector
import os, json

GROQ_API_KEY = os.environ.get("API_KEY")
MODEL_NAME = "meta-llama/llama-4-scout-17b-16e-instruct"

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class BankApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Bank Alert System Simulator")
        self.geometry("1100x700")

        self.accounts = load_accounts()
        self.detector = AIDetector(model_name=MODEL_NAME, api_key=GROQ_API_KEY)

        self.left_frame = ctk.CTkFrame(master=self, width=260)
        self.left_frame.pack(side="left", fill="y", padx=10, pady=10)
        ctk.CTkLabel(self.left_frame, text="Accounts", font=ctk.CTkFont(size=18, weight="bold")).pack(pady=(6,6))

        self.acct_buttons_frame = ctk.CTkScrollableFrame(self.left_frame, width=240, height=560)
        self.acct_buttons_frame.pack(padx=6, pady=6)
        self.account_btns = {}
        for a in self.accounts:
            btn = ctk.CTkButton(self.acct_buttons_frame, text=f"{a['id']} • {a['name']} ({a['balance']})", anchor="w",
                                command=lambda _id=a['id']: self.select_account(_id), width=220)
            btn.pack(pady=4, padx=2, anchor="w")
            self.account_btns[a['id']] = btn


        self.mid_frame = ctk.CTkFrame(master=self)
        self.mid_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        self.selected_account_id = None
        self.details_label = ctk.CTkLabel(self.mid_frame, text="Select an account", font=ctk.CTkFont(size=16, weight="bold"))
        self.details_label.pack(anchor="nw", pady=(6,6))
        self.balance_label = ctk.CTkLabel(self.mid_frame, text="")
        self.balance_label.pack(anchor="nw", pady=(0,10))
        self.tx_history = ctk.CTkTextbox(self.mid_frame, width=700, height=420)
        self.tx_history.pack(fill="both", expand=True)


        self.right_frame = ctk.CTkFrame(master=self, width=300)
        self.right_frame.pack(side="right", fill="y", padx=10, pady=10)
        ctk.CTkLabel(self.right_frame, text="Actions", font=ctk.CTkFont(size=16, weight="bold")).pack(pady=(6,6))
        self.amount_entry = ctk.CTkEntry(self.right_frame, placeholder_text="Amount (e.g. 100.50)")
        self.amount_entry.pack(pady=6)
        self.note_entry = ctk.CTkEntry(self.right_frame, placeholder_text="Note (optional)")
        self.note_entry.pack(pady=6)
        self.deposit_btn = ctk.CTkButton(self.right_frame, text="Deposit", command=self.deposit)
        self.deposit_btn.pack(pady=6, fill="x")
        self.withdraw_btn = ctk.CTkButton(self.right_frame, text="Withdraw", command=self.withdraw)
        self.withdraw_btn.pack(pady=6, fill="x")

        ctk.CTkLabel(self.right_frame, text="Transfer To (Account ID)").pack(pady=(12,0))
        self.transfer_to_entry = ctk.CTkEntry(self.right_frame, placeholder_text="ACCT0001")
        self.transfer_to_entry.pack(pady=6)
        self.transfer_btn = ctk.CTkButton(self.right_frame, text="Transfer", command=self.transfer)
        self.transfer_btn.pack(pady=6, fill="x")

        ctk.CTkButton(self.right_frame, text="Run AI Check", fg_color="#b21c1c", hover_color="#d43c3c", command=self.run_ai_check).pack(pady=(20,6), fill="x")

        ctk.CTkLabel(self.right_frame, text="Alerts", font=ctk.CTkFont(size=14, weight="bold")).pack(pady=(12,6))
        self.alerts_box = ctk.CTkTextbox(self.right_frame, width=280, height=220)
        self.alerts_box.pack()


        if self.accounts:
            self.select_account(self.accounts[0]["id"])

    def refresh_account_buttons(self):
        for a in self.accounts:
            btn = self.account_btns.get(a['id'])
            if btn:
                btn.configure(text=f"{a['id']} • {a['name']} ({a['balance']})")

    def select_account(self, acct_id):
        self.selected_account_id = acct_id
        acct = next((x for x in self.accounts if x["id"] == acct_id), None)
        if not acct:
            return
        self.details_label.configure(text=f"{acct['id']} • {acct['name']}")
        self.balance_label.configure(text=f"Balance: ₹ {acct['balance']:.2f}")
        self.tx_history.delete("0.0", "end")

        txs = list(reversed(acct.get("transactions", [])[-100:]))  # newest first
        for t in txs:
            ln = f"{t.get('timestamp','')[:19]} | {t.get('type')} | ₹{t.get('amount')}"
            if "from" in t:
                ln += f" from {t['from']}"
            if "to" in t:
                ln += f" to {t['to']}"
            if t.get("note"):
                ln += f" • {t.get('note')}"
            self.tx_history.insert("end", ln + "\n")
        self.tx_history.see("end")

    def deposit(self):
        if not self.selected_account_id:
            return
        amt = self.amount_entry.get().strip()
        note = self.note_entry.get().strip()
        try:
            tx = add_deposit(self.accounts, self.selected_account_id, float(amt), note=note)
            self.accounts = load_accounts()
            self.refresh_account_buttons()
            self.select_account(self.selected_account_id)
            self.alert(f"Deposited ₹{amt} into {self.selected_account_id}")
        except Exception as e:
            self.alert(f"Deposit failed: {e}")

    def withdraw(self):
        if not self.selected_account_id:
            return
        amt = self.amount_entry.get().strip()
        note = self.note_entry.get().strip()
        try:
            tx = add_withdraw(self.accounts, self.selected_account_id, float(amt), note=note)
            self.accounts = load_accounts()
            self.refresh_account_buttons()
            self.select_account(self.selected_account_id)
            self.alert(f"Withdrew ₹{amt} from {self.selected_account_id}")
        except Exception as e:
            self.alert(f"Withdraw failed: {e}")

    def transfer(self):
        if not self.selected_account_id:
            return
        to_id = self.transfer_to_entry.get().strip()
        amt = self.amount_entry.get().strip()
        note = self.note_entry.get().strip()
        try:
            tx_out, tx_in = add_transfer(self.accounts, self.selected_account_id, to_id, float(amt), note=note)
            self.accounts = load_accounts()
            self.refresh_account_buttons()
            self.select_account(self.selected_account_id)
            self.alert(f"Transferred ₹{amt} from {self.selected_account_id} to {to_id}")
        except Exception as e:
            self.alert(f"Transfer failed: {e}")

    def alert(self, text):
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        self.alerts_box.insert("end", f"[{now}] {text}\n")
        self.alerts_box.see("end")
        print("[ALERT]", text)

    def run_ai_check(self):
        t = threading.Thread(target=self._run_ai_check_worker, daemon=True)
        t.start()

    def _run_ai_check_worker(self):
        self.alerts_box.delete("0.0", "end")
        self.alert("Starting detectors...")
        txs = get_recent_transactions(self.accounts, limit=500)

        result = self.detector.analyze(txs)
        alerts = result.get("alerts", [])
        if not alerts:
            self.alert("No suspicious patterns detected.")

            for btn in self.account_btns.values():
                btn.configure(fg_color=None)
            return
        self.alert(f"Detected {len(alerts)} alert(s).")

        for a in alerts:
            acct = a.get("account_id")
            reason = a.get("reason", "")
            sev = a.get("severity", "low")
            ex = a.get("example_transactions", [])
            self.alert(f"[{sev.upper()}] {acct}: {reason}")

            btn = self.account_btns.get(acct)
            if btn:
                color = "#ff9999" if sev == "low" else ("#ff6666" if sev == "medium" else "#ff3b3b")
                btn.configure(fg_color=color)

        self.alerts_box.insert("end", "\n=== RAW ALERTS JSON ===\n")
        self.alerts_box.insert("end", json.dumps(result, indent=2, default=str))
        self.alerts_box.see("end")

if __name__ == "__main__":
    app = BankApp()
    app.mainloop()
