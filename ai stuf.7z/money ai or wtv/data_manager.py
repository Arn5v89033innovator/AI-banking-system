import json, uuid
from datetime import datetime, timezone

ACCOUNTS_FILE = "accounts.json"

def load_accounts():
    with open(ACCOUNTS_FILE, "r") as f:
        return json.load(f)

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, "w") as f:
        json.dump(accounts, f, indent=2, default=str)

def find_account(accounts, acct_id):
    for a in accounts:
        if a["id"] == acct_id:
            return a
    return None

def add_deposit(accounts, acct_id, amount, note=None):
    acct = find_account(accounts, acct_id)
    if acct is None:
        raise ValueError("Account not found")
    acct["balance"] = round(acct["balance"] + float(amount), 2)
    tid = str(uuid.uuid4())
    tx = {
        "id": tid,
        "type": "deposit",
        "amount": float(amount),
        "timestamp": datetime.now(tz=timezone.utc).isoformat() + "Z",
        "note": note or ""
    }
    acct["transactions"].append(tx)
    save_accounts(accounts)
    return tx

def add_withdraw(accounts, acct_id, amount, note=None):
    acct = find_account(accounts, acct_id)
    if acct is None:
        raise ValueError("Account not found")
    if acct["balance"] < float(amount):
        raise ValueError("Insufficient funds")
    acct["balance"] = round(acct["balance"] - float(amount), 2)
    tid = str(uuid.uuid4())
    tx = {
        "id": tid,
        "type": "withdraw",
        "amount": float(amount),
        "timestamp": datetime.now(tz=timezone.utc).isoformat() + "Z",
        "note": note or ""
    }
    acct["transactions"].append(tx)
    save_accounts(accounts)
    return tx

def add_transfer(accounts, from_id, to_id, amount, note=None):
    from_acct = find_account(accounts, from_id)
    to_acct = find_account(accounts, to_id)
    if from_acct is None or to_acct is None:
        raise ValueError("Account not found")
    if from_acct["balance"] < float(amount):
        raise ValueError("Insufficient funds")
    from_acct["balance"] = round(from_acct["balance"] - float(amount), 2)
    to_acct["balance"] = round(to_acct["balance"] + float(amount), 2)
    tid = str(uuid.uuid4())
    ts = datetime.now(tz=timezone.utc).isoformat() + "Z"
    tx_out = {
        "id": tid,
        "type": "transfer_out",
        "amount": float(amount),
        "to": to_id,
        "timestamp": ts,
        "note": note or ""
    }
    tx_in = {
        "id": tid,
        "type": "transfer_in",
        "amount": float(amount),
        "from": from_id,
        "timestamp": ts,
        "note": note or ""
    }
    from_acct["transactions"].append(tx_out)
    to_acct["transactions"].append(tx_in)
    save_accounts(accounts)
    return tx_out, tx_in

def get_recent_transactions(accounts, limit=200):
    """list of the most recent transactions, descending by timestamp"""
    txs = []
    for a in accounts:
        for t in a.get("transactions", []):
            tcopy = dict(t)
            if "from" not in tcopy and tcopy.get("type") in ("withdraw", "transfer_out"):
                tcopy["account"] = a["id"]
            if "from" in tcopy:
                tcopy.setdefault("account", tcopy["from"])
            else:
                tcopy.setdefault("account", a["id"])
            txs.append(tcopy)
    txs_sorted = sorted(txs, key=lambda x: x.get("timestamp", ""), reverse=True)
    return txs_sorted[:limit]