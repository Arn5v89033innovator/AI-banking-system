import json, random, uuid
from datetime import datetime, timezone

def make_account(i):
    acct_id = f"ACCT{i:04d}"
    name = f"User {i:02d}"
    balance = round(random.uniform(100, 10000), 2)
    return {
        "id": acct_id,
        "name": name,
        "balance": balance,
        "transactions": []
    }

def main():
    accounts = [make_account(i) for i in range(1, 51)]
    now = datetime.now(tz=timezone.utc).isoformat() + "Z"
    # a few historical transfers cuz y not
    for _ in range(200):
        a = random.choice(accounts)
        b = random.choice(accounts)
        if a is b:
            continue
        amt = round(random.uniform(1, 500), 2)
        tid = str(uuid.uuid4())
        ts = datetime.now(tz=timezone.utc).isoformat() + "Z"
        # withdraw from a -> deposit to b
        a["transactions"].append({
            "id": tid,
            "type": "transfer_out",
            "amount": amt,
            "to": b["id"],
            "timestamp": ts
        })
        b["transactions"].append({
            "id": tid,
            "type": "transfer_in",
            "amount": amt,
            "from": a["id"],
            "timestamp": ts
        })
    with open("accounts.json", "w") as f:
        json.dump(accounts, f, indent=2)
    print("Wrote accounts.json with 50 accounts.")

if __name__ == "__main__":
    main()
