import customtkinter as ctk
from PIL import Image
from datetime import datetime
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import multiprocessing
from gtts import gTTS
from playsound import playsound
import threading
import os
import time
import json
from langchain.prompts import PromptTemplate
from langchain_groq import ChatGroq
from langchain.schema import HumanMessage
from typing import override

llm = ChatGroq(
	model_name="meta-llama/llama-4-scout-17b-16e-instruct",
	temperature=0.7,
	api_key="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"
)
conversation_history = []

def get_response(content, include_context=True):
	"""
	Classify the content into predefined categories.
	"""
	prompt = PromptTemplate(
		input_variables=["content", "balance", "monthly_income", "monthly_expenses", "debts", "savings", "goal", "risk_tolerance", "history"],
		template='''You are a professional financial planning assistant designed to help users make smart, safe, and personalized financial decisions.
Your goal is to analyze the user's current balance, income, expenses, debts, and goals, and then recommend the best possible next financial actions they can take.

Your advice should be:

Personalized: Tailored to the user's given balance, goals, and situation.

Actionable: Include clear next steps (e.g., “invest X amount in a high-yield savings account” or “set aside 10% for emergency funds”).

Balanced: Prioritize financial stability, savings, and low-risk options unless the user specifies otherwise.

Educational: Briefly explain why each recommendation is beneficial.

Ethical and safe: Avoid speculative or illegal advice. Never promise guaranteed profits.

Always structure your answer in this format:

Current Financial Overview — summarize what the user has told you.

Immediate Priorities — what the user should do first.

Short-Term Plan (0-6 months) — budget, debt, or savings suggestions.

Long-Term Strategy (6+ months) — investments or major goals.

Why This Works — a brief rationale behind your advice.

Example Input that you'll resolve:
Current balance: ₹45000
Monthly income: ₹60000
Monthly expenses: ₹40000
Debts: None
Savings: ₹10000 in bank
Goals: Build emergency fund and start small investments
Risk tolerance: Low

Question: What's the best thing I can do with my money right now?

Example Output of the above Input:
1. Current Financial Overview:
You have ₹45,000 available and earn ₹60,000 monthly with ₹40,000 in expenses, leaving about ₹20,000 disposable income.

2. Immediate Priorities:
Set aside ₹30,000 from your balance to build an emergency fund (3 months of basic expenses).

3. Short-Term Plan (0-6 months):
Continue saving ₹10,000/month until you reach ₹1,20,000 in your emergency fund.

4. Long-Term Strategy (6+ months):
Once the emergency fund is complete, invest 20% of your disposable income in a low-risk mutual fund or fixed deposit.

5. Why This Works:
This approach ensures financial safety first, builds your savings buffer, and then allows stable, low-risk growth.
		
		
Current Balance: ₹{balance}
Monthly Income: ₹{monthly_income}
Monthly Expenses: ₹{monthly_expenses}
Debts: {debts}
Savings: {savings}
Goals: {goal}
Risk tolerance: {risk_tolerance}
Conversation History: {history}
User Input: {content}

Advice:'''
	)

	data = json.load(open('./config.json'))

	message = HumanMessage(content=prompt.format(content=content, balance=data['balance'], monthly_income=data['monthly_income'], monthly_expenses=data['monthly_expenses'], debts=data['debts'], savings=data['savings'], goal=data['goal'], risk_tolerance=data['risk_tolerance'], history=conversation_history if include_context else "No prior conversation."))
	response = llm.invoke([message]).content.strip()
	if include_context: 
		conversation_history.append((content, response))
	return response

def main():
	app = ctk.CTk()
	app.geometry("370x650")
	app.title("Evan Plan")
	app.resizable(False, False)

	image = Image.open("./img.png")
	bg = ctk.CTkImage(light_image=image, size=(370, 650))

	main_page = ctk.CTkFrame(app)
	main_page.place(relwidth=1, relheight=1)

	label1 = ctk.CTkLabel(main_page, image=bg, text="")
	label1.place(x=0, y=0)
	
	def open_chatBot():
		app.destroy()
		run_chatBot()
		main()

	welcome_label_1 = ctk.CTkLabel(main_page, text="Welcome to", font=("Comic Sans", 20))
	welcome_label_2 = ctk.CTkLabel(main_page, text="VISHWAAS", font=("Comic Sans", 50))
	chatbot_button = ctk.CTkButton(main_page, text="Need help?", width=150, height=50, font=("Comic Sans", 20), command=open_chatBot)

	welcome_label_1.place(relx=0.087, rely=0.04)
	welcome_label_2.place(relx=0.087, rely=0.08)
	chatbot_button.place(relx=0.3, rely=0.65)

	main_page.tkraise()

	app.mainloop()

def run_chatBot():
	llama = LlamaApp()

	ctk.set_appearance_mode("System")
	ctk.set_default_color_theme("blue")

	multiprocessing.Process(target=llama.mainloop, daemon=True).run()

def get_numbers(floor, room):
	room_no = ctk.CTkEntry.get(room)
	floor_no = ctk.CTkEntry.get(floor)

	room_no = int(room_no)
	floor_no = int(floor_no)

	generate_evacuation_plan(floor_no, room_no)

def generate_evacuation_plan(num_floors, rooms_per_floor):
	room_width = 6
	room_height = 4
	hallway_width = 3
	floor_spacing = 5
	stair_width = 4
	exit_width = 5

	rooms_per_side = min(100, rooms_per_floor)

	fig, ax = plt.subplots(figsize=(rooms_per_side * room_width / 1.5, num_floors * (room_height + floor_spacing) / 1.5))

	for floor in range(num_floors):
		y_offset = floor * (room_height + hallway_width + floor_spacing)

		for room in range(rooms_per_side):
			x_offset = room * room_width
			room_rect = patches.Rectangle((x_offset, y_offset), room_width, room_height, edgecolor='black', facecolor='lightblue')
			ax.add_patch(room_rect)

			room_label = f"F{floor + 1}R{room + 1}"
			ax.text(x_offset + room_width / 2, y_offset + room_height / 2, room_label,
					ha='center', va='center', fontsize=8, color='black')

		for room in range(rooms_per_side):
			x_offset = room * room_width
			room_rect = patches.Rectangle((x_offset, y_offset - room_height - hallway_width), room_width, room_height, edgecolor='black', facecolor='lightblue')
			ax.add_patch(room_rect)

			room_label = f"F{floor + 1}B{room + 1}"
			ax.text(x_offset + room_width / 2, y_offset - hallway_width - room_height / 2, room_label,
					ha='center', va='center', fontsize=8, color='black')

		hallway_rect = patches.Rectangle((0, y_offset - hallway_width), rooms_per_side * room_width, hallway_width,
										  edgecolor='black', facecolor='gray')
		ax.add_patch(hallway_rect)

		stair_x = -stair_width
		stair_rect = patches.Rectangle((stair_x, y_offset - room_height - hallway_width), stair_width, 2 * room_height + hallway_width,
										edgecolor='black', facecolor='lightgreen')
		ax.add_patch(stair_rect)
		ax.text(stair_x + stair_width / 2, y_offset, "Stairs",
				ha='center', va='center', fontsize=8, color='black')

		exit_x = rooms_per_side * room_width
		exit_rect = patches.Rectangle((exit_x, y_offset - room_height - hallway_width), exit_width, 2 * room_height + hallway_width,
									   edgecolor='black', facecolor='red')
		ax.add_patch(exit_rect)
		ax.text(exit_x + exit_width / 2, y_offset, "Exit",
				ha='center', va='center', fontsize=8, color='white')

		ax.arrow(rooms_per_side * room_width / 2, y_offset - hallway_width / 2, 0, -2,
				 head_width=1, head_length=1, fc='red', ec='red')

	ax.set_xlim(-stair_width - 1, rooms_per_side * room_width + exit_width + 1)
	ax.set_ylim(-hallway_width - (room_height + floor_spacing), num_floors * (room_height + hallway_width + floor_spacing))
	ax.set_aspect('equal')
	ax.axis('off')
	ax.set_title("Floor Evacuation Plan")
	
	plt.savefig("output.jpg")  

	plt.show()

class LlamaApp(ctk.CTk):
	def __init__(self):
		super().__init__()

		self.title("ChatBot")
		self.geometry("600x700")
		self.resizable(False, False)

		self.chat_display = ctk.CTkTextbox(self, width=560, height=500, wrap="word", state="disabled", corner_radius=10)
		self.chat_display.grid(row=0, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="nsew")

		self.input_box = ctk.CTkEntry(self, placeholder_text="Type your message here...", width=460, height=40, corner_radius=10)
		self.input_box.grid(row=1, column=0, padx=(20, 10), pady=(0, 20), sticky="ew")
		self.input_box.bind("<Return>", self.handle_user_input)

		self.send_button = ctk.CTkButton(self, text="Send", command=self.handle_user_input, width=80, height=40, corner_radius=10)
		self.send_button.grid(row=1, column=1, padx=(10, 20), pady=(0, 20), sticky="e")

	def handle_user_input(self, event=None):
		user_message = self.input_box.get().strip()
		if user_message:
			self.display_message("You", user_message)

			response = self.generate_response(user_message)
			self.display_ai_message(response)

	def display_ai_message(self, response):
		self.chat_display.configure(state="normal")
		timestamp = datetime.now().strftime("%H:%M")
		first_chunk = True
		for word in response.split(" "):
			if first_chunk:
				formatted_message = f"[{timestamp}] Bot: {word} "
				self.chat_display.insert("end", formatted_message)
				self.chat_display.see("end")
				self.chat_display.update()
				first_chunk = False
			else:
				self.chat_display.insert("end", f"{word} ")
				self.chat_display.see("end")
				self.chat_display.update()
			time.sleep(0.03)
		self.chat_display.insert("end", "\n")
		self.chat_display.see("end")       
		self.chat_display.update()
		self.chat_display.configure(state="disabled")

	def display_message(self, sender, message):
		self.input_box.delete(0, "end")
		self.chat_display.configure(state="normal")
		timestamp = datetime.now().strftime("%H:%M")
		formatted_message = f"[{timestamp}] {sender}: {message}\n"
		self.chat_display.insert("end", formatted_message)
		self.chat_display.see("end")
		self.chat_display.configure(state="disabled")

	def generate_response(self, user_message):
		timestamp = datetime.now().strftime("%H:%M")
		self.chat_display.configure(state="normal")
		self.chat_display.insert("end", f"[{timestamp}] Bot: Thinking...\n")
		self.chat_display.update()
		self.chat_display.configure(state="disabled")
		response = get_response(user_message)
		speechresp = (' '.join((response.split()[:50]))).replace("*", '')
		responsetts = gTTS(speechresp, tld= "us")

		if os.path.isfile("./responsevoice.mp3"):
			os.remove("./responsevoice.mp3")

		responsetts.save("responsevoice.mp3")

		sound_thread = threading.Thread(target=lambda: playsound("./responsevoice.mp3"))
		sound_thread.start()
		return response

if __name__ == "__main__":
	main()
